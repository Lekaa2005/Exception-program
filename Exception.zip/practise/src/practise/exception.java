package practise;

public class exception {
	public static void main(String[] args) {
		try {                //error in try block is clarified and rectified in catch block
			int a=134;
			int b=0;
			int c=a/b;
			System.out.println("divide :" +c);
		}catch(Exception e){    
			System.err.println(e);   //to show what the error is
			System.out.println("divide by zero error");
			
		}
        finally {     //even there is error in program finally block will execuete its task
        	System.out.println("dark devil");
        }
	}
}
